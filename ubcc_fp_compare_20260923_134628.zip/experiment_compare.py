#!/usr/bin/env python3
"""ExperimentExtractor / ExperimentComparator for UBCC E2E campaigns.

Given a run log directory produced by tests/e2e/run_multi.sh (gem5/ubio/nsim
logs for a single TC), ExperimentExtractor parses every timestamped event and
reconstructs per-request transport performance.  ExperimentComparator then
compares pairs of extractors (e.g. native gem5 vs ported private simulator)
across those per-request metrics with robust handling of missing files,
malformed lines, gzip logs and sampling metadata.

CLI:
    extract:  python3 scripts/experiment_compare.py extract DIR --label X --out x.json
    compare:  python3 scripts/experiment_compare.py compare a.json b.json \\
                  --labels baseline,candidate [--out cmp.json] [--csv cmp.csv]
"""

import argparse
import gzip
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

SCHEMA_VERSION = 1

# ---------------------------------------------------------------------------
# generic helpers
# ---------------------------------------------------------------------------

def _percentile(sorted_vals: Sequence[float], q: float) -> float:
    """Linear-interpolation percentile on an ascending-sorted sequence."""
    if not sorted_vals:
        return float("nan")
    if len(sorted_vals) == 1:
        return float(sorted_vals[0])
    pos = (len(sorted_vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(sorted_vals[lo])
    frac = pos - lo
    return float(sorted_vals[lo]) * (1.0 - frac) + float(sorted_vals[hi]) * frac


def _open_text(path: str):
    """Open .log/.txt as text, transparently handling gzip."""
    try:
        with open(path, "rb") as probe:
            magic = probe.read(2)
        if magic == b"\x1f\x8b":
            return gzip.open(path, "rt", errors="replace")
        return open(path, "rt", errors="replace")
    except OSError:
        return None


# ---------------------------------------------------------------------------
# ExperimentExtractor
# ---------------------------------------------------------------------------

# [TRACE-PERF] ts|logged_id|component|reqId|pa|EVENT|rest
_RE_TRACE_PERF = re.compile(
    r"\[TRACE-PERF\]\s*(\d+)\|(\d+)\|([A-Za-z0-9_-]+)\|(\d+)\|"
    r"([0-9a-fxA-F]+)\|([A-Za-z0-9_+-]+)\|?(.*)"
)

# [TRACE-PERF] 第 3 列可能出现的组件名

# 常见文本日志扩展名（不强制，其他扩展名走嗅探）
_TEXT_EXT = (".log", ".txt", ".out", ".err", ".stdout", ".stderr", ".exit")
# 明确不当日志处理的扩展名
_DENY_EXT = (".zip", ".elf", ".json", ".tsv", ".ini", ".png", ".jpg",
             ".svg", ".pdf", ".py", ".pyc", ".so", ".o", ".a", ".html",
             ".gz")   # 只有 .log.gz 单独放行


def _sniff_text(path: str, probe_bytes: int = 512) -> bool:
    """粗判一个未知扩展名的文件是不是文本日志（排除二进制）。"""
    try:
        with open(path, "rb") as fh:
            head = fh.read(probe_bytes)
    except OSError:
        return False
    if not head:
        return True          # 空文件当文本（读出来也是 0 事件）
    if b"\x00" in head:
        return False
    printable = sum(1 for b in head
                    if 32 <= b < 127 or b in (9, 10, 13))
    return printable / len(head) >= 0.9


# line-declared node identity (authoritative when the path is ambiguous),
# e.g. "node=" / "nid=" / "node_id=" key=value inside a marker line
_RE_KV_NODE = re.compile(
    r"\b(?:node|node_id|nid|nodeid)\s*[:=]\s*(\d+)", re.IGNORECASE)

# gem5/ubio printf protocol markers, optionally followed by key=value fields
_KV_RE = re.compile(r"([A-Za-z][A-Za-z0-9_]*)=([^\s,]+)")
_RE_MARKER = re.compile(r"\[([A-Z0-9][A-Za-z0-9_-]*)\]")

# root transaction types that open a request lifecycle
_LIFECYCLE_SEND = {
    "ReadReq", "UpgradeReq", "WritebackReq", "WriteCleanFull",
    "WriteEvictFull", "EvictReq", "CleanUnique", "AtomicReq",
}
# response-ish gem5 receive types that may close a request
_RESP_RECV_HINT = {
    "ReadResp", "UpgradeResp", "ClearResp", "WritebackResp", "EvictResp",
    "UpgradeDoneResp", "RecallResp", "InvalidateAck",
}

_RE_PASSED = re.compile(r">>> TC(\d+) PASSED <<<")
_RE_FAILED = re.compile(r">>> TC(\d+) FAILED <<<")

# gem5_tc1_node2 / gem5_tc1_node2_s1
_RE_GEM5_DIR = re.compile(r"gem5_tc(\d+)_node(\d+)(?:_s(\d+))?")
# ubio_tc1_n0_s0/... or ubio_n0_s0/...
_RE_UBIO_DIR = re.compile(r"ubio(?:_tc(\d+))?_n(\d+)_s(\d+)")
_RE_NSIM_FILE = re.compile(r"nsim(?:_tc(\d+))?\.log")
_RE_VERIFY_FILE = re.compile(r"verify(?:_tc(\d+))?\.log")
_RE_SIMOUT_FILE = re.compile(r"simout(?:_tc(\d+))?(?:_node(\d+))?\.log")
_RE_MATRIX_FILE = re.compile(r"matrix\.tsv$")


class ExperimentExtractor:
    """Parse one experiment's logs (a single run_multi.sh LOG_BASE directory).

    Robustness rules:
      * missing files / unreadable files are skipped and counted;
      * malformed lines are counted, never raised;
      * duplicate identical event tuples are collapsed;
      * .log.gz handled transparently;
      * event memory is bounded via ``max_events`` (oldest beyond the cap are
        dropped from ``events`` but chain statistics are still computed from
        the streaming aggregate);
      * log-directory layout differences (ubio_n0_s0 vs ubio_tc3_n0_s0) and
        unknown marker types are tolerated.
    """

    def __init__(self, log_dir: str, label: Optional[str] = None,
                 tc: Optional[int] = None, max_events: int = 2_000_000):
        self.log_dir = os.path.abspath(log_dir)
        self.label = label or os.path.basename(self.log_dir)
        self.tc = tc
        self.max_events = max_events

        self.events: List[Dict[str, Any]] = []       # timestamped events
        self.untimed_counts: Counter = Counter()     # [MARKER] without ts
        self.files_scanned: List[str] = []
        self.files_missing: List[str] = []
        self.parse_errors: int = 0
        self.duplicates_dropped: int = 0
        self.events_truncated: bool = False

        self.requests: List[Dict[str, Any]] = []     # per-request records
        self.verdict: Optional[str] = None
        self.read_vals: List[Dict[str, Any]] = []
        self.child_exit: Dict[str, int] = {}

        self._seen_event_keys: set = set()
        # node/socket identity.  ``node``/``socket`` are path-derived; when
        # the log itself declares a different node identity the line-declared
        # value wins and the override is counted in summary.
        self.kv_node_overrides: int = 0
        self.kv_node_conflicts: int = 0
        # duplicates in raw marker text (tee/merged-stream duplicates)
        self.stream_dup_dropped: int = 0
        # merged-file-level attribute notes (multi-node log in one file)
        self.multi_node_files: List[str] = []
        self._seen_marker_lines: set = set()
        self.marker_by_node: Dict[Tuple[str, int], int] = {}

    # -- discovery ---------------------------------------------------------

    def _classify(self, rel_path: str):
        """Map a file path to (component, node, socket, kind)."""
        parts = rel_path.replace("\\", "/").split("/")
        joined = "/".join(parts)
        for p in reversed(parts):  # deepest first
            m = _RE_GEM5_DIR.search(p)
            if m:
                return ("gem5", int(m.group(2)),
                        int(m.group(3) or 0), "log")
        for p in reversed(parts):
            m = _RE_UBIO_DIR.search(p)
            if m:
                return ("ubio", int(m.group(2)),
                        int(m.group(3)), "log")
        base = os.path.basename(joined)
        m = _RE_NSIM_FILE.match(base)
        if m:
            return ("nsim", 0, 0, "log")
        m = _RE_VERIFY_FILE.match(base)
        if m:
            return ("verify", 0, 0, "verify")
        m = _RE_SIMOUT_FILE.match(base)
        if m:
            return ("guest", int(m.group(2) or -1), 0, "guest")
        return (None, None, None, None)

    def discover_files(self, root_dir=None) -> List[Tuple[str, Tuple]]:
        """枚举疑似日志文件。

        命名不做强约束：常见文本扩展名直接收；其它扩展名（或没有扩展
        名，比如 ``simout``）做一次小的“是否像文本”的嗅探再决定，避免
        把 .elf/.zip 之类二进制当成日志读。
        """
        found: List[Tuple[str, Tuple]] = []
        for root, _dirs, names in os.walk(root_dir or self.log_dir):
            for name in sorted(names):
                if _RE_MATRIX_FILE.search(name):
                    continue
                path = os.path.join(root, name)
                lower = name.lower()
                if lower.endswith(_DENY_EXT):
                    continue
                is_text = (lower.endswith(_TEXT_EXT)
                           or (lower.endswith(".log.gz"))
                           or _sniff_text(path))
                if not is_text:
                    continue
                rel = os.path.relpath(path, root_dir or self.log_dir)
                comp, node, sock, kind = self._classify(rel)
                if kind == "log" and comp is None:
                    continue
                if lower.endswith(".exit"):
                    found.append((path, ("exit", 0, 0, "exit")))
                else:
                    found.append((path, (comp, node, sock, kind)))
        return found

    # -- parsing -----------------------------------------------------------

    def _add_event(self, ev: Dict[str, Any]) -> None:
        key = (ev.get("ts"), ev.get("component"), ev.get("req_id"),
               ev.get("pa"), ev.get("event"), ev.get("msg_type"),
               ev.get("node"), ev.get("socket"))
        if key in self._seen_event_keys:
            self.duplicates_dropped += 1
            return
        self._seen_event_keys.add(key)
        self.events.append(ev)
        if len(self.events) > self.max_events:
            # drop oldest quarter; aggregates already computed by caller
            cut = self.max_events // 4
            dropped = {id(e) for e in self.events[:cut]}
            self.events = self.events[cut:]
            self.events_truncated = True

    def _parse_trace_perf(self, line: str, component: str, node: int,
                          socket: int) -> Optional[Dict[str, Any]]:
        m = _RE_TRACE_PERF.search(line)
        if not m:
            return None
        try:
            ts = int(m.group(1))
            logged_id = int(m.group(2))
            req_id = int(m.group(4))
        except ValueError:
            self.parse_errors += 1
            return None
        # 组件归类规则（三桶语义）：
        #   ubio / nsim —— 固定的外部中转模块，两侧行为一致，行内声明可信；
        #   其余一切组件名（gem5 / ksim / msim / metaRNF …）都归入 "gem5"
        #   桶，表示“请求侧模拟器”。私有模拟器自己的打点不叫 gem5 时，
        # 也能正确锚定请求链，否则其事件会落进 unknown，导致
        # requests_complete=0、request_stats_ps 为空、比较全 null。
        # 第 2 列的含义不统一：gem5 行是节点号，ubio 的 SEND 行其实是
        # 目的 module。因此只有在“组件归入 gem5 桶且目录名没给出节点”
        # 时，才拿它当节点号，其余情况只当作 logged_id 记录下来。
        declared_comp = m.group(3)
        if declared_comp in ("ubio", "nsim"):
            comp = declared_comp
        elif component in ("ubio", "nsim"):
            comp = component
        else:
            comp = "gem5" if (declared_comp or component) else "unknown"
        nd = node
        if nd is None and comp == "gem5":
            nd = logged_id
        pa_raw = m.group(5)
        rest = m.group(7)
        tail_tokens = [t for t in rest.strip().split("|") if t]
        msg_type = tail_tokens[0].strip() if tail_tokens else ""
        kv: Dict[str, str] = {}
        for tok in tail_tokens[1:]:
            km = _KV_RE.match(tok.strip())
            if km:
                kv[km.group(1)] = km.group(2)
        ev = {
            "ts": ts,
            "component": comp,
            "node": nd,
            "socket": socket,
            "logged_id": logged_id,
            "req_id": req_id,
            "pa": pa_raw,
            "event": m.group(6),
            "msg_type": msg_type,
            "kv": kv,
            "marker": "TRACE-PERF",
        }
        self._add_event(ev)
        return ev

    def _parse_plain_marker(self, line: str) -> Optional[str]:
        for m in _RE_MARKER.finditer(line):
            marker = m.group(1)
            if marker == "TRACE-PERF":
                continue
            return marker
        return None

    def _parse_kv_tail(self, line: str) -> Dict[str, str]:
        kv = {}
        for km in _KV_RE.finditer(line):
            kv[km.group(1)] = km.group(2)
        return kv

    @staticmethod
    def _is_guest_marker(marker: str) -> bool:
        return marker in {"READ_VAL", "E2E_META", "E2E_PROGRESS",
                          "BEFORE_WR", "AFTER_WR", "BEFORE_RD"}

    def parse(self, extra_dirs=None) -> "ExperimentExtractor":
        roots = [self.log_dir] + list(extra_dirs or [])
        found = []
        for r in roots:
            for item in self.discover_files(r):
                found.append(item)
        for path, (comp, node, sock, kind) in found:
            if kind == "exit":
                base = os.path.basename(path)
                try:
                    with open(path, "r", errors="replace") as fh:
                        txt = fh.read().strip()
                    self.child_exit[base] = int(txt.split(":")[0].strip())
                except Exception:
                    self.parse_errors += 1
                self.files_scanned_add(path)
                continue
            self.files_scanned_add(path)
            fh = _open_text(path)
            if fh is None:
                self.files_missing.append(path)
                continue
            with fh:
                for line in fh:
                    if comp == "verify" or comp == "guest":
                        self._parse_verify_or_guest(line, comp)
                        continue
                    if "[TRACE-PERF]" in line:
                        ev = self._parse_trace_perf(line, comp, node, sock)
                        if ev is not None:
                            continue
                        self.parse_errors += 1
                        continue
                    # verdict 兜底：不管文件叫什么，只要行里有
                    # “>>> TC<N> PASSED/FAILED <<<”或“TC<N> PASSED/FAILED”
                    # 就识别成验证结论（kimi 侧输出位置可能和我们不同）。
                    if ("PASSED" in line or "FAILED" in line) and \
                            self.verdict is None:
                        self._parse_verify_or_guest(line, comp)
                    marker = self._parse_plain_marker(line)
                    if marker is None:
                        continue
                    if self._is_guest_marker(marker):
                        self._parse_guest_marker(marker, line)
                        continue
                    if len(line) > 2048:
                        line = line[:2048]
                    self._count_marker(marker, line, comp, node, sock)
        self._build_requests()
        self._build_summary()
        return self

    def files_scanned_add(self, path: str) -> None:
        self.files_scanned.append(os.path.relpath(path, self.log_dir))

    # 统计无时间戳的 marker 时做去重。同一条 marker 正文如果同时出现在
    # stdout 和 stderr（tee），或者在合并文件里被重复输出，只算一次；
    # 去重的范围限定在同一个 controller（comp/node/socket）内，
    # 不同 node 上的同名 marker 各自计数。
    # 如果 marker 行里自带 node= / nid=，以行内值为准，并另记一份
    # “marker x node”的分布，便于发现多个 node 的日志被合到一起的情况。
    def _count_marker(self, marker: str, line: str, comp: str, node: int,
                      socket: int) -> None:
        text = line.strip()
        if not text:
            return
        key = (comp, node, socket, marker, text)
        if key in self._seen_marker_lines:
            self.stream_dup_dropped += 1
            return
        self._seen_marker_lines.add(key)
        self.untimed_counts[marker] += 1
        kn = _RE_KV_NODE.search(text)
        if kn:
            decl_node = int(kn.group(1))
            if node is not None and node != decl_node:
                self.kv_node_conflicts += 1
            mkey = (marker, decl_node)
            self.marker_by_node[mkey] = self.marker_by_node.get(mkey, 0) + 1
            if node is not None and node != decl_node:
                self.kv_node_overrides += 1
        elif node is not None:
            mkey = (marker, node)
            self.marker_by_node[mkey] = self.marker_by_node.get(mkey, 0) + 1

    def _parse_verify_or_guest(self, line: str, comp: str) -> None:
        m = _RE_PASSED.search(line)
        if m:
            self.verdict = "PASSED"
            return
        m = _RE_FAILED.search(line)
        if m:
            self.verdict = "FAILED"
            return
        # 宽松兜底：行内只要出现 “TC<N> PASSED/FAILED” 也算结论
        # （私有侧的 verify 输出格式可能没有 >>> <<< 包裹）。
        if self.verdict is None:
            lm = re.search(r"\bTC\s*(\d+)\s+(PASSED|FAILED)\b", line)
            if lm:
                self.verdict = lm.group(2)
                return
        rm = re.search(
            r"\[READ_VAL\]\s+node=(\d+)\s+home=(\d+).*?expected=(\w+)\s+"
            r"actual=(\w+)\s+(MATCH|MISMATCH)", line)
        if rm:
            self.read_vals.append({
                "node": int(rm.group(1)), "home": int(rm.group(2)),
                "expected": rm.group(3), "actual": rm.group(4),
                "verdict": rm.group(5),
            })

    def _parse_guest_marker(self, marker: str, line: str) -> None:
        rm = re.search(
            r"\[READ_VAL\].*?expected=(\w+)\s+actual=(\w+)\s+(MATCH|MISMATCH)",
            line)
        if rm:
            self.read_vals.append({
                "expected": rm.group(1), "actual": rm.group(2),
                "verdict": rm.group(3),
            })
        self.untimed_counts[marker] += 1

    # -- request chain reconstruction --------------------------------------

    def _build_requests(self) -> None:
        by_key: Dict[Tuple[int, str], List[Dict[str, Any]]] = defaultdict(list)
        for ev in self.events:
            key = (ev["req_id"], ev.get("pa") or "0x0")
            by_key[key].append(ev)
        for (req_id, pa), evs in by_key.items():
            evs.sort(key=lambda e: (e["ts"], _EVENT_ORDER.get(
                e.get("event", ""), 9), e.get("msg_type", "")))
            instances = self._split_instances(evs)
            for inst in instances:
                self.requests.append(self._summarize_chain(req_id, pa, inst))

    @staticmethod
    def _split_instances(evs: List[Dict[str, Any]]) -> List[List[Any]]:
        """Split reused (reqId, PA) into separate request instances."""
        instances: List[List[Any]] = []
        current: List[Any] = []
        for ev in evs:
            if (ev["component"] == "gem5" and ev["event"] == "SEND"
                    and ev["msg_type"] in _LIFECYCLE_SEND and current):
                # a new root send closes the previous instance
                instances.append(current)
                current = []
            current.append(ev)
        if current:
            instances.append(current)
        return instances

    @staticmethod
    def _summarize_chain(req_id: int, pa: str,
                         evs: List[Dict[str, Any]]) -> Dict[str, Any]:
        gem5_sends = [e for e in evs
                      if e["component"] == "gem5" and e["event"] == "SEND"]
        gem5_recvs = [e for e in evs
                      if e["component"] == "gem5" and e["event"] == "RECV"]
        first = evs[0]["ts"] if evs else 0
        last = evs[-1]["ts"] if evs else 0
        req_node = next((e["node"] for e in evs
                         if e["component"] == "gem5"), None)
        req_type = gem5_sends[0]["msg_type"] if gem5_sends else ""
        resp_types = sorted({e["msg_type"] for e in gem5_recvs
                             if e["msg_type"] in _RESP_RECV_HINT})
        resp_recv = next((e for e in gem5_recvs
                          if e["msg_type"] in _RESP_RECV_HINT
                          and gem5_sends
                          and e["ts"] >= gem5_sends[0]["ts"]), None)
        e2e = None
        if resp_recv is not None and gem5_sends:
            e2e = resp_recv["ts"] - gem5_sends[0]["ts"]
        nsim_hops = sum(1 for e in evs if e["component"] == "nsim")
        ubio_relay = sum(1 for e in evs
                         if e["component"] == "ubio"
                         and e["event"] in ("RECV_GEM5", "SEND_GEM5"))
        cross = nsim_hops > 0
        return {
            "req_id": req_id,
            "pa": pa,
            "requester_node": req_node,
            "type": req_type,
            "first_ts": first,
            "last_ts": last,
            "duration_ps": last - first,
            "e2e_latency_ps": e2e,
            "cross_node": cross,
            "n_events": len(evs),
            "ubio_relay_events": ubio_relay,
            "resp_types": resp_types,
        }

    # -- summary ------------------------------------------------------------

    def _build_summary(self) -> None:
        ticks = [e["ts"] for e in self.events]
        complete = [r for r in self.requests
                    if r["e2e_latency_ps"] is not None]
        by_type: Dict[str, List[int]] = defaultdict(list)
        for r in complete:
            key = r["type"] or "unknown"
            by_type[key].append(r["e2e_latency_ps"])
        stats = {}
        for k, vals in by_type.items():
            svals = sorted(vals)
            n = len(svals)
            p05 = _percentile(svals, 0.05)
            p95 = _percentile(svals, 0.95)
            trimmed = [v for v in vals if p05 <= v <= p95]
            tmean = (sum(trimmed) / len(trimmed)) if trimmed else \
                sum(vals) / len(vals)
            q1 = _percentile(svals, 0.25)
            q3 = _percentile(svals, 0.75)
            iqr = q3 - q1
            fence = q3 + 3.0 * iqr
            outliers = [v for v in vals if v > fence] if iqr > 0 else []
            stats[k] = {
                "count": len(vals),
                "mean_ps": sum(vals) / len(vals),
                "trimmed_mean_ps": tmean,
                "min_ps": svals[0],
                "p50_ps": _percentile(svals, 0.50),
                "p90_ps": _percentile(svals, 0.90),
                "p95_ps": p95,
                "p99_ps": _percentile(svals, 0.99),
                "max_ps": svals[-1],
                "outlier_count": len(outliers),
                "outlier_frac": len(outliers) / n,
                "outlier_max_ps": outliers[-1] if outliers else None,
            }
        self.summary = {
            "label": self.label,
            "tc": self.tc,
            "log_dir": self.log_dir,
            "schema_version": SCHEMA_VERSION,
            "verdict": self.verdict,
            "events_total": len(self.events),
            "events_truncated": self.events_truncated,
            "duplicates_dropped": self.duplicates_dropped,
            "parse_errors": self.parse_errors,
            "stream_dup_dropped": self.stream_dup_dropped,
            "kv_node_conflicts": self.kv_node_conflicts,
            "kv_node_overrides": self.kv_node_overrides,
            "untimed_markers": dict(self.untimed_counts),
            "untimed_marker_by_node": {
                f"{m}@n{k}": v for (m, k), v in self.marker_by_node.items()},
            "files_scanned": self.files_scanned,
            "files_missing": self.files_missing,
            "first_ts": min(ticks) if ticks else None,
            "last_ts": max(ticks) if ticks else None,
            "component_events": dict(Counter(
                e["component"] for e in self.events)),
            # 组件|事件|消息类型 的计数（前 60 个），用于自查：
            # complete=0 时，看这里有没有 请求侧|SEND|<根类型> 和
            # 请求侧|RECV|<响应类型>（响应类型须在 _RESP_RECV_HINT 里）。
            "event_breakdown": dict(Counter(
                f"{e['component']}|{e['event']}|{e['msg_type']}"
                for e in self.events).most_common(60)),
            "requests_total": len(self.requests),
            "requests_complete": len(complete),
            "read_vals": self.read_vals,
            "child_exit": self.child_exit,
            "request_stats_ps": stats,
        }

    # -- serialization -------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "summary": self.summary,
            "requests": self.requests,
            "events_omitted": True,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExperimentExtractor":
        obj = ExperimentExtractor.__new__(ExperimentExtractor)
        obj.log_dir = data["summary"]["log_dir"]
        obj.label = data["summary"]["label"]
        obj.tc = data["summary"].get("tc")
        obj.summary = data["summary"]
        obj.requests = data.get("requests", [])
        obj.events = []
        obj.untimed_counts = Counter(
            obj.summary.get("untimed_markers", {}))
        obj.parse_errors = obj.summary.get("parse_errors", 0)
        return obj

    def write_json(self, path: str) -> None:
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh, indent=1)


# ordering preference when timestamps tie inside one chain
_EVENT_ORDER = {"SEND": 0, "RECV_GEM5": 1, "RECV_NET": 2, "RECV": 3,
                "SEND_GEM5": 4, "SEND_NET": 5, "FWD": 6}


# ---------------------------------------------------------------------------
# ExperimentComparator
# ---------------------------------------------------------------------------

class ExperimentComparator:
    """Compare pairs of ExperimentExtractor results.

    ``pairs`` is a sequence of (label, baseline, candidate) where baseline and
    candidate are ExperimentExtractor objects or paths to their saved JSON.
    """

    def __init__(self, pairs: Sequence[Tuple[str, Any, Any]],
                 max_relative_warning: float = 0.20):
        self.pairs: List[Tuple[str, ExperimentExtractor,
                               ExperimentExtractor]] = []
        self.max_relative_warning = max_relative_warning
        for item in pairs:
            if len(item) == 3:
                label, base, cand = item
            else:
                raise ValueError("pairs must be (label, baseline, candidate)")
            self.pairs.append((label, _as_extractor(base),
                               _as_extractor(cand)))

    def compare(self) -> List[Dict[str, Any]]:
        reports = []
        for label, base, cand in self.pairs:
            reports.append(self._compare_pair(label, base, cand))
        return reports

    def _compare_pair(self, label: str, base: ExperimentExtractor,
                      cand: ExperimentExtractor) -> Dict[str, Any]:
        b, c = base.summary, cand.summary
        global_metrics = {}
        for key in ("events_total", "requests_total", "requests_complete",
                    "parse_errors", "duplicates_dropped"):
            global_metrics[key] = {
                "baseline": b.get(key),
                "candidate": c.get(key),
            }
        # aggregate marker counts (untimed protocol stages)
        mk_b = defaultdict(int, b.get("untimed_markers", {}))
        mk_c = defaultdict(int, c.get("untimed_markers", {}))
        marker_rows = []
        for marker in sorted(set(mk_b) | set(mk_c)):
            vb, vc = mk_b.get(marker, 0), mk_c.get(marker, 0)
            marker_rows.append({
                "marker": marker,
                "baseline": vb,
                "candidate": vc,
                "delta": vc - vb,
                "rel_diff": _safe_ratio(vc - vb, vb),
            })
        marker_rows.sort(key=lambda r: (-abs(r["delta"]), r["marker"]))

        # per-request-type latency stats
        st_b = b.get("request_stats_ps", {})
        st_c = c.get("request_stats_ps", {})
        cat_rows = []
        for cat in sorted(set(st_b) | set(st_c)):
            row = {"category": cat}
            for field in ("count", "mean_ps", "trimmed_mean_ps", "p50_ps",
                          "p90_ps", "p95_ps", "p99_ps"):
                vb = (st_b.get(cat) or {}).get(field)
                vc = (st_c.get(cat) or {}).get(field)
                row["baseline_" + field] = vb
                row["candidate_" + field] = vc
                if field == "count":
                    row["count_delta"] = _delta(vb, vc)
                    tol = _count_tolerance(vb, vc)
                    row["count_within_tolerance"] = (
                        None if tol is None else abs(_delta(vb, vc) or 0)
                        <= tol)
                    row["count_tolerance"] = tol
                else:
                    row[field + "_delta"] = _delta(vb, vc)
                    row[field + "_ratio"] = _safe_ratio(vc, vb)
                    row[field + "_pct_change"] = (
                        None if row[field + "_ratio"] is None
                        else (row[field + "_ratio"] - 1.0) * 100.0)
            ob = st_b.get(cat, {}).get("outlier_frac")
            oc = st_c.get(cat, {}).get("outlier_frac")
            row["baseline_outlier_frac"] = ob
            row["candidate_outlier_frac"] = oc
            small = min(x for x in [st_b.get(cat, {}).get("count"),
                                    st_c.get(cat, {}).get("count")]
                        if x is not None) if (cat in st_b and cat in st_c) \
                else 0
            row["small_sample"] = (small is not None and small < 5)
            cat_rows.append(row)

        alerts = []
        structural = []
        for row in cat_rows:
            # primary verdict uses the ROBUST median (p50); mean / tails are
            # advisory so that a single straggler request or one extra /
            # missing instance cannot flip the verdict.
            pct = row.get("p50_ps_pct_change")
            if (pct is not None and not row["small_sample"]
                    and row.get("count_within_tolerance") is not False):
                if abs(pct) > self.max_relative_warning * 100:
                    tag = "REGRESSION" if pct > 0 else "IMPROVEMENT"
                    alerts.append(f"{row['category']}: p50 {pct:+.1f}% "
                                  f"({tag} beyond "
                                  f"{self.max_relative_warning * 100:.0f}%)")
            elif row.get("count_within_tolerance") is False:
                structural.append(
                    f"{row['category']}: request count mismatch "
                    f"{row['baseline_count']} -> {row['candidate_count']} "
                    f"(beyond tolerance {row['count_tolerance']})")
            for field, qname in (("p95_ps", "p95"), ("p99_ps", "p99")):
                tp = row.get(field + "_pct_change")
                if tp is None or row["small_sample"]:
                    continue
                if abs(tp) > self.max_relative_warning * 100 * 1.5:
                    alerts.append(
                        f"{row['category']}: {qname} {tp:+.1f}% "
                        f"(TAIL-DRIFT advisory based on robust count)")
        return {
            "pair": label,
            "baseline": b.get("label"),
            "candidate": c.get("label"),
            "verdict": {"baseline": b.get("verdict"),
                        "candidate": c.get("verdict")},
            "global": global_metrics,
            "marker_diffs_top": marker_rows[:15],
            "request_categories": cat_rows,
            "alerts": alerts,
            "structural_alerts": structural,
        }

    def to_json(self, reports: List[Dict[str, Any]]) -> str:
        return json.dumps(reports, indent=1)

    def to_table(self, reports: List[Dict[str, Any]]) -> str:
        lines = []
        for rep in reports:
            lines.append(f"== {rep['pair']} ==")
            lines.append(f"  baseline: {rep['baseline']} "
                         f"(verdict={rep['verdict']['baseline']})")
            lines.append(f"  candidate:{rep['candidate']} "
                         f"(verdict={rep['verdict']['candidate']})")
            lines.append("  %-28s %10s %10s %8s %10s %10s" %
                         ("category", "cnt_base", "cnt_cand",
                          "delta", "mean_b(ps)", "mean_c(ps)"))
            for row in rep["request_categories"]:
                lines.append("  %-28s %10s %10s %8s %10s %10s" % (
                    row["category"],
                    _fmt(row["baseline_count"]), _fmt(row["candidate_count"]),
                    _fmt(row["count_delta"]),
                    _fmt(row["baseline_mean_ps"]),
                    _fmt(row["candidate_mean_ps"])))
            for row in rep["request_categories"]:
                p50 = row.get("p50_ps_pct_change")
                if p50 not in (None, 0.0) and abs(p50) > 1e-6 and \
                        row.get("small_sample"):
                    pass
            for alert in rep.get("structural_alerts") or []:
                lines.append("  STRUCTURAL " + alert)
            for alert in rep["alerts"]:
                lines.append("  ALERT " + alert)
            top = rep.get("marker_diffs_top") or []
            if top:
                lines.append("  top marker diffs:")
                for m in top[:5]:
                    lines.append("    %-32s %6d -> %6d" % (
                        m["marker"], m["baseline"], m["candidate"]))
            lines.append("")
        return "\n".join(lines)


def _as_extractor(x: Any) -> ExperimentExtractor:
    if isinstance(x, ExperimentExtractor):
        return x
    if isinstance(x, str):
        with open(x, "r") as fh:
            return ExperimentExtractor.from_dict(json.load(fh))
    if isinstance(x, dict):
        return ExperimentExtractor.from_dict(x)
    raise TypeError(f"cannot convert {type(x)} to ExperimentExtractor")


def _safe_ratio(num, den):
    try:
        if num is None or den is None:
            return None
        if den == 0:
            return None if num == 0 else float("inf")
        return float(num) / float(den)
    except (TypeError, ValueError):
        return None


def _count_tolerance(b, c):
    """请求条数的容差。

    小样本（比如只有 2 条请求）因为一次重试或多/少一个实例就会有差异，
    属于正常抖动；只有大样本上的系统性偏移才值得当成结构不一致。
    容差取 max(2, 两侧较大值的 5%)。
    """
    if b is None or c is None:
        return None
    try:
        return max(2.0, 0.05 * max(abs(float(b)), abs(float(c))))
    except (TypeError, ValueError):
        return None


def _delta(a, b):
    if a is None or b is None:
        return None
    try:
        return b - a
    except TypeError:
        return None


def _fmt(x):
    if x is None:
        return "-"
    if isinstance(x, float):
        return f"{x:.1f}" if abs(x) < 1e6 else f"{x:.3e}"
    return str(x)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd")
    # Python 3.6 不支持 add_subparsers(required=True)，改用属性设置
    sub.required = True

    p_extract = sub.add_parser("extract")
    p_extract.add_argument("log_dir", nargs="+",
                           help="one or more log dirs (ubsim + merged "
                                "workload/guest output dirs); all are "
                                "scanned and merged into one record")
    p_extract.add_argument("--label", default=None)
    p_extract.add_argument("--tc", type=int, default=None)
    p_extract.add_argument("--out", default=None)
    p_extract.add_argument("--print-summary", action="store_true")

    p_cmp = sub.add_parser("compare")
    p_cmp.add_argument("jsons", nargs="+", metavar="EXTRACT_JSON")
    p_cmp.add_argument("--labels", default=None)
    p_cmp.add_argument("--out", default=None)
    p_cmp.add_argument("--csv", default=None)
    p_cmp.add_argument("--max-relative", type=float, default=0.25)

    args = ap.parse_args()

    if args.cmd == "extract":
        ex = ExperimentExtractor(args.log_dir[0], label=args.label, tc=args.tc)
        ex.parse(extra_dirs=args.log_dir[1:])
        out = args.out or os.path.join(
            os.path.dirname(args.log_dir[0].rstrip("/")) or ".",
            (args.label or "experiment") + "_extract.json")
        ex.write_json(out)
        s = ex.summary
        print(f"[EXTRACT] label={s['label']} verdict={s['verdict']} "
              f"events={s['events_total']} requests={s['requests_total']} "
              f"complete={s['requests_complete']} "
              f"parse_errors={s['parse_errors']} "
              f"files={len(s['files_scanned'])} "
              f"missing={len(s['files_missing'])} "
              f"components={s['component_events']} out={out}")
        return 0

    if args.cmd == "compare":
        labels = args.labels.split(",") if args.labels else []
        if len(args.jsons) % 2 != 0:
            print("compare needs an even number of extractor JSONs "
                  "(baseline candidate baseline candidate ...)", flush=True)
            return 2
        pairs = []
        for i in range(0, len(args.jsons), 2):
            idx = i // 2
            label = labels[idx] if idx < len(labels) else f"pair{idx}"
            base = _as_extractor(args.jsons[i])
            cand = _as_extractor(args.jsons[i + 1])
            pairs.append((label, base, cand))
        comp = ExperimentComparator(pairs,
                                    max_relative_warning=args.max_relative)
        reports = comp.compare()
        text = comp.to_table(reports)
        print(text)
        if args.out:
            with open(args.out, "w") as fh:
                fh.write(comp.to_json(reports))
        if args.csv:
            _write_csv(reports, args.csv)
        return 0
    return 1


def _write_csv(reports: List[Dict[str, Any]], path: str) -> None:
    fields = ["pair", "category", "baseline_count", "candidate_count",
              "count_delta", "baseline_mean_ps", "candidate_mean_ps",
              "mean_ps_pct_change", "baseline_p95_ps", "candidate_p95_ps",
              "p95_ps_pct_change"]
    with open(path, "w") as fh:
        fh.write(",".join(fields) + "\n")
        for rep in reports:
            for row in rep["request_categories"]:
                fh.write(",".join(str(_csvval(row.get(f)))
                                  for f in fields) + "\n")


def _csvval(x):
    if x is None:
        return ""
    return x


if __name__ == "__main__":
    sys.exit(main())
