#!/usr/bin/env python3
"""gem5(0717 native) 与 ksim(私有移植) 的性能指纹对比入口。

包里已经带好了 gem5 侧的结果（gem5-side-results/tc<N>.json），
你需要做的是：填好下面两个函数，然后运行本脚本。

  1) fill_tcid_logdir_mapping()  —— 从私有侧的 summary 文件里读出
     “TC 号 -> 日志目录”，只需填 summary_paths 和解析逻辑；
  2) fill_ksim_input_files()     —— 从上面的映射里取目录，一般不用改。

脚本不依赖 Docker、不依赖仓库目录、不依赖任何绝对路径：
把压缩包解压到任何目录都能跑，结果目录和脚本同层。

三个阶段：
  ksim     先调用一次 fill_tcid_logdir_mapping()，再枚举 TC 调
           fill_ksim_input_files() 取目录，生成 ksim-side-results/tc<N>.json；
           取不到目录的 TC 自动跳过。
  compare  对同时有两侧结果的 TC 做对比，写 comparison/tc<N>.json，
           并汇总成 comparison/summary_all.json
  pack     可选（默认关闭，加 --pack 才执行）。把两侧结果和脚本重新
           打成一个 zip，方便把结果回传。

常用命令：
    python3 run_experiment_compare.py                  # ksim + compare
    python3 run_experiment_compare.py --skip compare   # 只提取
    python3 run_experiment_compare.py --pack           # 再打个回传包
"""

import argparse
import json
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List

HERE = Path(__file__).resolve().parent

# 结果目录：都和脚本放在同一层
G5_RESULT_DIR = HERE / "gem5-side-results"      # 包里已带，只读
KSIM_RESULT_DIR = HERE / "ksim-side-results"    # 需要你生成
COMPARE_DIR = HERE / "comparison"

KNOWN_SKIP = {112, 116}

REGISTERED_TCS = sorted(set(
    list(range(1, 55))
    + [63, 64, 80, 81, 82, 84, 85]
    + list(range(90, 102))
    + [102]
    + list(range(110, 120))))
SUITES = [tc for tc in REGISTERED_TCS if tc not in KNOWN_SKIP]


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------

def resolve_fp_script() -> Path:
    """找到 experiment_compare.py。

    在仓库里运行时它在 scripts/ 下；压缩包解压后所有 .py 是平铺的，
    所以两种位置都试一下。
    """
    for cand in (HERE / "scripts" / "experiment_compare.py",
                 HERE / "experiment_compare.py"):
        if cand.exists():
            return cand
    raise FileNotFoundError(
        "找不到 experiment_compare.py（应在 scripts/ 下或与脚本同目录）")


def _run(cmd):
    # 兼容 Python 3.6：没有 capture_output / text 这两个关键字
    return subprocess.run(cmd, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,
                          universal_newlines=True)


# ---------------------------------------------------------------------------
# 阶段 1：ksim(私有移植) 侧 —— 需要你填路径
# ---------------------------------------------------------------------------

# 全局缓存：TC 号 -> {"ubsim_logs": ..., "workload_logs": ... or None}
# 由 fill_tcid_logdir_mapping() 填充一次，fill_ksim_input_files() 只负责查表。
_TCID_TO_LOGDIR: Dict[int, Dict[str, str]] = {}
_MAPPING_FILLED: bool = False


def fill_tcid_logdir_mapping() -> Dict[int, Dict[str, str]]:
    """读取私有侧 summary 文件，建立 TC 号到日志目录的映射。

    **这个函数需要在私有一侧填两处**：
      1) summary_paths：列出所有 summary 文件的路径；
      2) while 循环里的解析逻辑：从每个文件的内容里解析出
         tc_id、ubsim_logdir、（可选）workload_logdir。

    约定填进 _TCID_TO_LOGDIR 的值形如：
        tcid_to_logdir[tc_id] = {
            "ubsim_logs": "...",       # 必填
            "workload_logs": "...",    # 可选，没有就省略或给 None
        }

    只会在提取前调用一次；重复调用直接返回缓存。
    """
    global _TCID_TO_LOGDIR, _MAPPING_FILLED
    if _MAPPING_FILLED:
        return _TCID_TO_LOGDIR

    # ==== TODO: 填好 summary 文件路径列表 ====
    summary_paths: List[str] = []

    tcid_to_logdir: Dict[int, Dict[str, str]] = {}
    for sum_path in summary_paths:
        with open(sum_path, "r") as f:
            lines = f.readlines()
        i, n = 0, len(lines)
        while i < n:
            # TODO: Impl
            # 例如：
            #   if lines[i].startswith('Passed'):
            #       tc_id = ...          从本行或后续行解析 TC 号
            #       ubsim_logdir = ...   解析 ubsim（gem5/nsim/ubio）日志目录
            #       workload_logdir = ...可选，workload 的 guest 输出目录
            #       tcid_to_logdir[tc_id] = {
            #           "ubsim_logs": ubsim_logdir,
            #           "workload_logs": workload_logdir,
            #       }
            #       i += 1
            i += 1

    _TCID_TO_LOGDIR = tcid_to_logdir
    _MAPPING_FILLED = True
    print(f"[map] 解析到 {len(_TCID_TO_LOGDIR)} 个 TC 的日志目录")
    return _TCID_TO_LOGDIR


def fill_ksim_input_files(tc_id: int) -> dict:
    """返回某个 TC 在私有一侧的日志位置（直接查 fill_tcid_logdir_mapping 的结果）。

    返回 dict 有两种形态：
      - 跳过这个 TC：
            {"tc_id": tc_id, "skip": "原因"}
      - 正常参与：
            {"tc_id": tc_id,
             "files": {"ubsim_logs": "<目录>",
                       "workload_logs": "<目录或 None>"}}
    """
    if not _MAPPING_FILLED:
        fill_tcid_logdir_mapping()

    entry = _TCID_TO_LOGDIR.get(tc_id)
    if not entry:
        return {"tc_id": tc_id, "skip": "summary 映射里没有这个 TC"}
    ubsim_dir = entry.get("ubsim_logs")
    workload_dir = entry.get("workload_logs")
    if not ubsim_dir or not Path(ubsim_dir).is_dir():
        return {"tc_id": tc_id, "skip": f"ubsim_logs 目录不存在: {ubsim_dir}"}
    return {
        "tc_id": tc_id,
        "files": {
            "ubsim_logs": ubsim_dir,
            "workload_logs": workload_dir or None,
        },
    }


def extract(tc_id: int, output_filename, input_files: dict) -> int:
    """把一个 TC 的私有侧日志提取成 ksim-side-results/tc<N>.json。

    input_files 就是 fill_ksim_input_files() 的返回值；其中 "files" 里的
    目录（ubsim_logs，以及可选的 workload_logs）会一起交给解析器合并处理。
    返回 0 表示成功，非 0 表示跳过或失败。
    """
    if input_files.get("skip"):
        print(f"[ks ] tc{tc_id:>3}: 跳过（{input_files['skip']}）")
        return 1

    files = (input_files or {}).get("files", {})
    ubsim_dir = files.get("ubsim_logs")
    workload_dir = files.get("workload_logs")
    if not ubsim_dir or not Path(ubsim_dir).is_dir():
        print(f"[ks ] tc{tc_id:>3}: 跳过（ubsim_logs 目录无效: {ubsim_dir}）")
        return 1

    dirs = [str(ubsim_dir)]
    if workload_dir and Path(workload_dir).is_dir():
        dirs.append(str(workload_dir))

    proc = _run([sys.executable, str(resolve_fp_script()), "extract", *dirs,
                 "--label", f"ksim_tc{tc_id}", "--tc", str(tc_id),
                 "--out", str(output_filename)])
    if proc.returncode == 0:
        print(f"[ks ] tc{tc_id:>3}: OK")
    else:
        print(f"[ks ] tc{tc_id:>3}: 失败 {proc.stderr.strip()[:140]}")
    return proc.returncode


def extract_ksim_side():
    """枚举所有 TC，调用 fill_ksim_input_files + extract；取不到目录的自动跳过。"""
    KSIM_RESULT_DIR.mkdir(parents=True, exist_ok=True)
    fill_tcid_logdir_mapping()   # 只调用一次；fill_ksim_input_files 只查表
    for tc in SUITES:
        output_filename = KSIM_RESULT_DIR / f"tc{tc}.json"
        extract(tc, output_filename, fill_ksim_input_files(tc))


# ---------------------------------------------------------------------------
# 阶段 2：比较
# ---------------------------------------------------------------------------

def run_comparisons():
    """对同时有两侧结果的 TC 做对比，并输出一张汇总表。

    每 TC 的明细写在 comparison/tc<N>.json；
    汇总（结构告警、时延告警、各请求类型的 p50/p95/p99 变化）写在
    comparison/summary_all.json。
    """
    fp_script = resolve_fp_script()
    COMPARE_DIR.mkdir(parents=True, exist_ok=True)
    summary = []

    for tc in SUITES:
        g5 = G5_RESULT_DIR / f"tc{tc}.json"
        ks = KSIM_RESULT_DIR / f"tc{tc}.json"
        if not g5.exists() or not ks.exists():
            print(f"[cmp] tc{tc:>3}: 跳过（缺少某一侧的结果）")
            continue

        out = COMPARE_DIR / f"tc{tc}.json"
        proc = _run([sys.executable, str(fp_script), "compare",
                     str(g5), str(ks),
                     "--labels", f"g5_tc{tc},ksim_tc{tc}",
                     "--out", str(out)])
        if proc.returncode != 0:
            print(f"[cmp] tc{tc:>3}: 失败 {proc.stderr.strip()[:140]}")
            continue

        with open(out) as fh:
            reports = json.load(fh)
        rep = reports[0] if isinstance(reports, list) and reports else reports
        summary.append({
            "tc": tc,
            "verdict": {"g5": rep.get("verdict", {}).get("baseline"),
                        "ksim": rep.get("verdict", {}).get("candidate")},
            "structural_alerts": rep.get("structural_alerts", []),
            "alerts": rep.get("alerts", []),
            "request_categories": [
                {"category": r.get("category"),
                 "baseline_count": r.get("baseline_count"),
                 "candidate_count": r.get("candidate_count"),
                 "count_delta": r.get("count_delta"),
                 "count_within_tolerance": r.get("count_within_tolerance"),
                 "p50_ps_pct_change": r.get("p50_ps_pct_change"),
                 "p95_ps_pct_change": r.get("p95_ps_pct_change"),
                 "p99_ps_pct_change": r.get("p99_ps_pct_change")}
                for r in rep.get("request_categories", [])],
        })
        print(f"[cmp] tc{tc:>3}: OK")

    (COMPARE_DIR / "summary_all.json").write_text(json.dumps(summary, indent=1))
    print(f"[cmp] 共 {len(summary)} 对 -> {COMPARE_DIR / 'summary_all.json'}")
    write_compact_summary(summary)


def write_compact_summary(summary, out_dir=COMPARE_DIR):
    """把完整 summary 压成一份人类可读的总结果。

    生成三个文件：
      comparison/summary_compact.txt    总览 + 需要关注的 TC（几行到几十行）
      comparison/summary_compact.json   只含 overall 统计和 offenders
      comparison/summary_compact.csv    每个 TC 一行，方便丢进表格
    """
    import csv

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for s in summary:
        worst_pct = None
        worst_cat = None
        for c in s.get("request_categories", []):
            pct = c.get("p50_ps_pct_change")
            if pct is None:
                continue
            if worst_pct is None or abs(pct) > abs(worst_pct):
                worst_pct, worst_cat = pct, c.get("category")
        rows.append({
            "tc": s["tc"],
            "g5": s["verdict"]["g5"],
            "ksim": s["verdict"]["ksim"],
            "structural": len(s.get("structural_alerts") or []),
            "alerts": len(s.get("alerts") or []),
            "worst_p50_pct": worst_pct,
            "worst_category": worst_cat,
        })

    offenders = [r for r in rows if r["structural"] or r["alerts"]]
    offenders.sort(key=lambda r: (
        -(abs(r["worst_p50_pct"]) if r["worst_p50_pct"] is not None else -1),
        r["tc"]))
    overall = {
        "compared": len(rows),
        "clean": len(rows) - len(offenders),
        "with_structural_mismatch": sum(1 for r in rows if r["structural"]),
        "with_alerts": sum(1 for r in rows if r["alerts"]),
        "not_pass": sorted(r["tc"] for r in rows if "PASSED" not in
                           (r["g5"], r["ksim"])),
    }

    lines = [
        "UBCC 性能指纹对比总览：gem5(0717) vs ksim",
        f"对比 TC 数: {overall['compared']}   "
        f"结构不一致: {overall['with_structural_mismatch']}   "
        f"时延告警: {overall['with_alerts']}   "
        f"完全一致: {overall['clean']}",
        "",
    ]
    if offenders:
        lines.append("需要关注（按最差 p50 漂移排序）:")
        lines.append("  tc     类别              p50%     结构  告警")
        for r in offenders[:20]:
            pct = r["worst_p50_pct"]
            lines.append("  %-6s %-16s %8s %5d %5d" % (
                f"tc{r['tc']}", r["worst_category"] or "-",
                "-" if pct is None else f"{pct:+.1f}",
                r["structural"], r["alerts"]))
        if len(offenders) > 20:
            lines.append(f"  ... 其余 {len(offenders) - 20} 个见 summary_compact.json")
    else:
        lines.append("需要关注: 无（所有 TC 结构一致、时延无告警）")

    top5 = sorted([r for r in rows if r["worst_p50_pct"] is not None],
                  key=lambda r: -abs(r["worst_p50_pct"]))[:5]
    if top5:
        lines.append("")
        lines.append("p50 漂移最大 top5:")
        for r in top5:
            lines.append("  %-6s %-16s %+.1f%%" % (
                f"tc{r['tc']}", r["worst_category"] or "-", r["worst_p50_pct"]))

    text = "\n".join(lines) + "\n"
    (out_dir / "summary_compact.txt").write_text(text)
    (out_dir / "summary_compact.json").write_text(json.dumps(
        {"overall": overall, "offenders": offenders},
        indent=1, ensure_ascii=False))
    with open(out_dir / "summary_compact.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["tc", "g5", "ksim", "structural_alerts", "alerts",
                    "worst_p50_pct_change", "worst_category"])
        for r in sorted(rows, key=lambda r: r["tc"]):
            w.writerow([r["tc"], r["g5"], r["ksim"], r["structural"],
                        r["alerts"],
                        "" if r["worst_p50_pct"] is None
                        else round(r["worst_p50_pct"], 1),
                        r["worst_category"] or ""])

    print(text.rstrip())
    print(f"[cmp] 精简总览 -> {out_dir / 'summary_compact.txt'}"
          f" / .json / .csv")
    return out_dir / "summary_compact.txt"


# ---------------------------------------------------------------------------
# 阶段 3：可选打包
# ---------------------------------------------------------------------------

def pack_zip(pack_dir: Path = Path(".")) -> Path:
    """把两侧结果和脚本打成一个 zip，默认放在当前目录。

    zip 内容：
      gem5-side-results/tc<N>.json   gem5 侧结果
      ksim-side-results/tc<N>.json   私有侧结果（解压包里只有空目录）
      comparison/                    对比结果
      run_experiment_compare.py      本脚本
      experiment_compare.py          extract / compare 引擎
      test_experiment_compare.py     引擎单测
    """
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pack_dir = Path(pack_dir)
    pack_dir.mkdir(parents=True, exist_ok=True)
    zip_path = pack_dir / f"ubcc_fp_compare_{stamp}.zip"
    KSIM_RESULT_DIR.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for tc in SUITES:
            p = G5_RESULT_DIR / f"tc{tc}.json"
            if p.exists():
                zf.write(p, f"gem5-side-results/tc{tc}.json")
        for tc in SUITES:
            p = KSIM_RESULT_DIR / f"tc{tc}.json"
            if p.exists():
                zf.write(p, f"ksim-side-results/tc{tc}.json")
        # 空目录占位：接收方解压后一定有这两个目录且可写
        for d in ("gem5-side-results/", "ksim-side-results/"):
            info = zipfile.ZipInfo(d)
            info.external_attr = (0o40755 << 16) | 0x10
            zf.writestr(info, "")
        if COMPARE_DIR.exists():
            for name in ("summary_compact.txt", "summary_compact.json",
                         "summary_compact.csv", "summary_all.json"):
                f = COMPARE_DIR / name
                if f.exists():
                    zf.write(f, f"comparison/{f.name}")

        zf.write(Path(__file__), Path(__file__).name)
        zf.write(resolve_fp_script(), "experiment_compare.py")
        test_file = HERE / "tests" / "scripts" / "test_experiment_compare.py"
        if not test_file.exists():
            test_file = HERE / "test_experiment_compare.py"
        if test_file.exists():
            zf.write(test_file, "test_experiment_compare.py")

    print(f"已打包 -> {zip_path}")
    return zip_path


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="gem5(0717) 与 ksim 的性能指纹提取与对比")
    ap.add_argument("--skip", default="",
                    help="要跳过的阶段，逗号分隔，可选：ksim,compare")
    ap.add_argument("--pack", action="store_true",
                    help="额外把两侧结果和脚本打成回传 zip")
    ap.add_argument("--pack-dir", default=".",
                    help="回传 zip 的存放目录（默认当前目录）")
    args = ap.parse_args()

    skip = {s.strip() for s in args.skip.split(",") if s.strip()}

    if "ksim" not in skip:
        extract_ksim_side()
    if "compare" not in skip:
        run_comparisons()
    if args.pack and "pack" not in skip:
        pack_zip(Path(args.pack_dir))
    return 0


if __name__ == "__main__":
    sys.exit(main())
