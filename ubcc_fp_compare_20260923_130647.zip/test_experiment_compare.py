#!/usr/bin/env python3
"""Self-contained unittest for ExperimentExtractor / ExperimentComparator.

Run: python3 tests/scripts/test_experiment_compare.py
"""

import gzip
import json
import os
import shutil
import sys
import tempfile
import unittest
from textwrap import dedent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..",
                                "scripts"))
from experiment_compare import (ExperimentComparator,  # noqa: E402
                                ExperimentExtractor)


def _write(path, text, gz=False):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    mode = "wt" if gz else "w"
    opener = gzip.open if gz else open
    with opener(path, mode) as fh:
        fh.write(dedent(text))


class TestExtractor(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="exp_cmp_")
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)

    def _gem5(self, node, text, tc=3, gz=False):
        p = os.path.join(self.tmp, f"gem5_tc3_node{node}", "stderr.log")
        _write(p, text, gz=gz)
        return p

    def test_basic_chain_and_stats(self):
        self._gem5(1, """
            [TRACE-PERF] 1000|1|gem5|72057594037927937|0x10018000000|SEND|ReadReq|dst=1
            junk line
            [TRACE-PERF] 1250|1|gem5|72057594037927937|0x10018000000|RECV|ReadResp|src=0
            """)
        d = os.path.join(self.tmp, "ubio_n1_s0")
        _write(os.path.join(d, "stderr.log"), """
            [TRACE-PERF] 1000|1|ubio|72057594037927937|0x10018000000|RECV_GEM5|ReadReq
            [TRACE-PERF] 1150|1|ubio|72057594037927937|0x10018000000|SEND_GEM5|ReadResp
            """)
        _write(os.path.join(self.tmp, "verify_tc3.log"),
               ">>> TC3 PASSED <<<\n")
        ex = ExperimentExtractor(self.tmp, label="t", tc=3).parse()
        s = ex.summary
        self.assertEqual(s["verdict"], "PASSED")
        self.assertEqual(s["events_total"], 4)
        self.assertEqual(s["parse_errors"], 0)
        self.assertEqual(s["requests_complete"], 1)
        self.assertEqual(ex.requests[0]["e2e_latency_ps"], 250)
        self.assertEqual(ex.requests[0]["cross_node"], False)
        st = s["request_stats_ps"]["ReadReq"]
        self.assertAlmostEqual(st["mean_ps"], 250.0)

    def test_gz_and_malformed_and_duplicates(self):
        self._gem5(0, """
            [TRACE-PERF] 100|0|gem5|5|0x0|SEND|ReadReq|dst=1
            [TRACE-PERF] 100|0|gem5|5|0x0|SEND|ReadReq|dst=1
            [TRACE-PERF] not-a-tuple
            [TRACE-PERF] 200|0|gem5|5|0x0|RECV|ReadResp|src=1
            """, gz=True)
        ex = ExperimentExtractor(self.tmp, label="g", tc=3).parse()
        s = ex.summary
        self.assertEqual(s["events_total"], 2)
        self.assertEqual(s["duplicates_dropped"], 1)
        self.assertEqual(s["parse_errors"], 1)
        self.assertEqual(ex.requests[0]["e2e_latency_ps"], 100)

    def test_missing_dir_and_empty(self):
        ex = ExperimentExtractor(os.path.join(self.tmp, "nope")).parse()
        self.assertEqual(ex.summary["events_total"], 0)
        self.assertIsNone(ex.summary["verdict"])

    def test_multi_socket_ubio_paths(self):
        _write(os.path.join(self.tmp, "ubio_tc3_n1_s1", "stdout.log"), """
            [TRACE-PERF] 500|2|ubio|9|0x20000000000|RECV_GEM5|UpgradeReq
            """)
        ex = ExperimentExtractor(self.tmp).parse()
        ev = ex.events[0]
        self.assertEqual((ev["component"], ev["node"], ev["socket"]),
                         ("ubio", 1, 1))

    def test_instance_split_on_reused_reqid(self):
        self._gem5(0, """
            [TRACE-PERF] 10|0|gem5|7|0xa|SEND|ReadReq|dst=0
            [TRACE-PERF] 20|0|gem5|7|0xa|RECV|ReadResp|src=0
            [TRACE-PERF] 30|0|gem5|7|0xa|SEND|ReadReq|dst=0
            [TRACE-PERF] 40|0|gem5|7|0xa|RECV|ReadResp|src=0
            """)
        ex = ExperimentExtractor(self.tmp).parse()
        self.assertEqual(len(ex.requests), 2)
        lat = [r["e2e_latency_ps"] for r in ex.requests]
        self.assertEqual(lat, [10, 10])

    def test_unsupported_marker_only_counts(self):
        _write(os.path.join(self.tmp, "ubio_n0_s0", "stdout.log"),
               "[UBCC-UPGRADE-COMMIT] pa=0x1 owner=0 reservedEpoch=5\n")
        ex = ExperimentExtractor(self.tmp).parse()
        self.assertEqual(ex.summary["untimed_markers"]
                         .get("UBCC-UPGRADE-COMMIT"), 1)
        self.assertEqual(ex.summary["events_total"], 0)


    def test_stream_mix_and_tee_dedupe(self):
        d = os.path.join(self.tmp, "gem5_tc3_node0")
        same = """
            [TRACE-PERF] 10|0|gem5|7|0xa|SEND|ReadReq|dst=1
            [TRACE-PERF] 20|0|gem5|7|0xa|RECV|ReadResp|src=1
            [EPSNF-RECV] node=0 type=1 addr=0xa"""
        _write(os.path.join(d, "stdout.log"), same)
        _write(os.path.join(d, "stderr.log"), same)
        ex = ExperimentExtractor(self.tmp, label="tee", tc=3).parse()
        s = ex.summary
        self.assertEqual(s["events_total"], 2)
        self.assertEqual(s["stream_dup_dropped"], 1)
        self.assertEqual(s["duplicates_dropped"], 2)
        self.assertEqual(s["untimed_markers"].get("EPSNF-RECV"), 1)

    def test_line_declared_node_beats_path(self):
        d = os.path.join(self.tmp, "ubio_n9_s0")
        _write(os.path.join(d, "stdout.log"), """
            [UBCC-INV-ACK] node=2 pa=0x1 ackNode=5 op=UPGRADE
            """)
        ex = ExperimentExtractor(self.tmp).parse()
        self.assertEqual(ex.summary["kv_node_conflicts"], 1)
        self.assertIn(("UBCC-INV-ACK", 2), ex.marker_by_node)

    def test_missing_request_not_structural(self):
        lines_b = []
        lines_c = []
        for i in range(10):
            lines_b.append(
                f"[TRACE-PERF] {1000 + i * 100}|0|gem5|{i}|0xa|SEND|"
                f"ReadReq|dst=1")
            lines_b.append(
                f"[TRACE-PERF] {1100 + i * 100}|0|gem5|{i}|0xa|RECV|"
                f"ReadResp|src=1")
            if i < 9:
                lines_c.append(lines_b[-2]); lines_c.append(lines_b[-1])
        lines_c.append(
            "[TRACE-PERF] 5000|0|gem5|99|0xa|SEND|ReadReq|dst=1")
        lines_c.append(
            "[TRACE-PERF] 55000|0|gem5|99|0xa|RECV|ReadResp|src=1")
        base = os.path.join(self.tmp, "b")
        cand = os.path.join(self.tmp, "c")
        _write(os.path.join(base, "gem5_tc3_node0", "stderr.log"),
               "\n".join(lines_b))
        _write(os.path.join(cand, "gem5_tc3_node0", "stderr.log"),
               "\n".join(lines_c))
        exb = ExperimentExtractor(base, label="b").parse()
        exc = ExperimentExtractor(cand, label="c").parse()
        comp = ExperimentComparator([("x", exb, exc)])
        rep = comp.compare()[0]
        self.assertEqual(rep["structural_alerts"], [])
        self.assertFalse(rep["request_categories"][0]["small_sample"])
        p50 = rep["request_categories"][0]["p50_ps_pct_change"]
        self.assertLess(abs(p50), 5.0)
        self.assertTrue(rep["alerts"])
        self.assertTrue(any("p99" in a for a in rep["alerts"]))


    def test_inline_component_used_when_path_is_opaque(self):
        # 目录名不带 gem5/ubio 前缀时，也应靠 [TRACE-PERF] 行内组件重建请求
        d = os.path.join(self.tmp, "opaque_name")
        _write(os.path.join(d, "stdout.log"), """
            [TRACE-PERF] 100|0|gem5|1|0xa|SEND|ReadReq|dst=0
            [TRACE-PERF] 160|0|gem5|1|0xa|RECV|ReadResp|src=0
            """)
        ex = ExperimentExtractor(self.tmp).parse()
        self.assertEqual(ex.summary["requests_total"], 1)
        self.assertEqual(ex.requests[0]["e2e_latency_ps"], 60)
        self.assertEqual(ex.requests[0]["requester_node"], 0)


    def test_extensionless_simout_and_odd_ext(self):
        # 无扩展名 simout + 奇怪扩展名 .out：都应被读到；二进制应被跳过
        d = os.path.join(self.tmp, "weird_run")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "simout"), "w") as fh:
            fh.write("[READ_VAL] node=1 home=1 off=0 expected=A actual=A MATCH\n")
        with open(os.path.join(d, "result_3.out"), "w") as fh:
            fh.write(">>> TC3 PASSED <<<\n")
        with open(os.path.join(d, "payload.elf"), "wb") as fh:
            fh.write(b"\x7fELF\x00\x00\x01binary\x00\x00")
        ex = ExperimentExtractor(self.tmp, label="w", tc=3).parse()
        s = ex.summary
        self.assertEqual(s["verdict"], "PASSED")
        self.assertEqual(len(s["read_vals"]), 1)
        names = " ".join(s["files_scanned"])
        self.assertIn("simout", names)
        self.assertIn("result_3.out", names)
        self.assertNotIn("payload.elf", names)

    def test_loose_verdict_without_angle_brackets(self):
        d = os.path.join(self.tmp, "logs_anywhere")
        _write(os.path.join(d, "run_output.txt"),
               "TC3 PASSED: 3 reads all MATCH\n")
        ex = ExperimentExtractor(self.tmp, label="loose", tc=3).parse()
        self.assertEqual(ex.summary["verdict"], "PASSED")


class TestComparator(unittest.TestCase):
    def _make_extractor(self, stats, events_total=10, verdict="PASSED"):
        class FakeEx:
            pass
        ex = ExperimentExtractor.__new__(ExperimentExtractor)
        ex.label = "fake"
        ex.requests = []
        ex.summary = {
            "label": "fake", "log_dir": "/tmp/fake", "verdict": verdict,
            "events_total": events_total, "requests_total": 5,
            "requests_complete": 5, "parse_errors": 0,
            "duplicates_dropped": 0,
            "untimed_markers": {"UBCC-UPGRADE-COMMIT": 3},
            "request_stats_ps": stats,
        }
        return ex

    def test_compare_pair_label_not_shadowed(self):
        base = self._make_extractor({
            "ReadReq": {"count": 8, "mean_ps": 100.0, "p50_ps": 100.0,
                        "p95_ps": 120.0, "p99_ps": 150.0}})
        cand = self._make_extractor({
            "ReadReq": {"count": 8, "mean_ps": 130.0, "p50_ps": 130.0,
                        "p95_ps": 160.0, "p99_ps": 200.0}})
        rep = ExperimentComparator([("my_pair", base, cand)]).compare()[0]
        self.assertEqual(rep["pair"], "my_pair")

    def test_compare_with_missing_category(self):
        base = self._make_extractor({
            "ReadReq": {"count": 10, "mean_ps": 200.0, "p50_ps": 200.0,
                        "p95_ps": 300.0, "p99_ps": 400.0}})
        cand = self._make_extractor({
            "ReadReq": {"count": 10, "mean_ps": 250.0, "p50_ps": 250.0,
                        "p95_ps": 350.0, "p99_ps": 450.0}})
        comp = ExperimentComparator([("p", base, cand)])
        rep = comp.compare()[0]
        row = rep["request_categories"][0]
        self.assertAlmostEqual(row["p50_ps_ratio"], 1.25)
        self.assertAlmostEqual(row["p50_ps_pct_change"], 25.0)
        self.assertTrue(any("ReadReq" in a for a in rep["alerts"]))

    def test_missing_category_is_none_safe(self):
        base = self._make_extractor({})
        cand = self._make_extractor({
            "ReadReq": {"count": 4, "mean_ps": 10.0, "p50_ps": 10.0,
                        "p95_ps": 10.0, "p99_ps": 10.0}})
        comp = ExperimentComparator([("m", base, cand)])
        rep = comp.compare()[0]
        row = rep["request_categories"][0]
        self.assertIsNone(row["baseline_mean_ps"])
        self.assertIsNone(row["mean_ps_ratio"])
        self.assertTrue(row["small_sample"])

    def test_from_json_roundtrip(self):
        tmpd = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmpd, ignore_errors=True)
        path = os.path.join(tmpd, "x.json")
        ex = self._make_extractor({})
        ex.write_json(path)
        with open(path) as fh:
            ex2 = ExperimentExtractor.from_dict(json.load(fh))
        self.assertEqual(ex2.summary["label"], "fake")


if __name__ == "__main__":
    unittest.main()
