#!/usr/bin/env python3
"""判别一个 UBCC 移植包大致对应哪个时间版本（用于和 gem5/父仓库 0717 基线对齐）。

用法（在包根目录下执行，也可 --root 指定）：

    python3 identify_version.py                 # 当前目录
    python3 identify_version.py --root /path/to/tree

做两件事：
  1) 计算若干关键文件的 sha1 前缀，和 0717 基线（gem5 63bc49e9ce /
     父仓库 28bad3be）对照；
  2) 检查若干“哨兵字符串”（某提交引入/删除），据此推断时间窗口。

结论只是**近似的版本窗口**，因为两边可能有自己的私有改动；关键文件
哈希全中才是精确匹配。
"""

import argparse
import hashlib
import os
import re
from pathlib import Path

# 0717 基线（父仓库 28bad3be / gem5 63bc49e9ce）关键文件 sha1 前缀
EXPECTED_HASHES = {
    "gem5/src/mem/ruby/protocol/chi/ep/EPRNFController.cc": "eb42b8eaec97",
    "gem5/src/mem/ruby/protocol/chi/ep/EPSNFController.cc": "72c544e66cf5",
    "gem5/src/mem/ruby/protocol/chi/ep/UBAdapter.cc": "59c5b6dd1e56",
    "gem5/src/mem/ruby/protocol/chi/ep/EPBackend.cc": "ac9e5638789b",
    "gem5/src/mem/ruby/protocol/chi/CHI-cache-actions.sm": "425df5d0a833",
    "gem5/src/mem/ruby/protocol/chi/CHI-cache-transitions.sm": "2812898ac6c8",
    "gem5/src/mem/ruby/protocol/chi/CHI-cache-funcs.sm": "007847f6ad43",
    "gem5/configs/ruby/CHI_ubcc_framework.py": "47fdf5c92b19",
    "modules/ubiomodule/ubio_main.cc": "7eb4a8899ca8",
    "modules/ubiomodule/UBCCController.cc": "81cb7a43efd5",
    "framework/Port.cc": "fdb4c541ac53",
    "framework/Port.hh": "52dcd63c1d9e",
    "tests/e2e/run_multi.sh": "3e7872c7a97b",
    "tests/e2e/test_e2e.py": "26bd6cc7023d",
    "tests/e2e/workloads/e2e_tc112_tbe_interference.c": "c27eb57a50c2",
}

# 哨兵：字符串 / 文件是否出现，对应提交相对 0717 的时间
#   "after":  该字符串出现 => 版本 >= 该日期
#   "before": 该字符串出现 => 版本 <= 该日期（之后被删掉）
SENTINELS = [
    # gem5 侧
    ("gem5/src/mem/ruby/protocol/chi/ep/EPRNFController.cc",
     "s_upgrade_drop_max_resends", "after", "2026-07-17",
     "0717 引入的 DROP watchdog 常量"),
    ("gem5/src/mem/ruby/protocol/chi/ep/EPRNFController.cc",
     "retryExhausted", "after", "2026-08-16",
     "0816“terminate exhausted upgrade retries”之后才有"),
    ("gem5/src/mem/ruby/protocol/chi/ep/EPRNFController.cc",
     "EPRNF-UPGRADE-TERMINAL", "after", "2026-08-16",
     "同上，0816 引入的终止标记"),
    ("gem5/src/mem/ruby/protocol/chi/ep/EPBackend.cc",
     "acceptedPending", "after", "2026-08-04",
     "0804“separate grant and clear epochs”之后才有"),
    ("gem5/src/mem/ruby/protocol/chi/ep/UBAdapter.cc",
     "_readyResponses", "before", "2026-07-17",
     "0717 及之前用 readyResponses 缓存"),
    # 采样策略（TRACE-PERF 门控）是 9 月“quiet endpoint”之后才有的
    ("protocol/TracePerfPolicy.hh", "", "after", "2026-09-01",
     "文件存在 => 0901 之后（TRACE-PERF 采样策略）"),
    # 父仓库侧
    ("tests/e2e/workloads/e2e_tc112_tbe_interference.c",
     "cpu_index % 4", "after", "2026-07-22",
     "0722“isolate TC112 writer lanes”改为本地 lane 计算"),
    ("tests/e2e/workloads/e2e_tc112_tbe_interference.c",
     "if (cpu_index == 0)", "before", "2026-07-17",
     "0717 及之前用全局 cpu_index 选 lane"),
    ("tests/e2e/run_multi.sh", "--wait-bloom-ready", "after", "2026-08-01",
     "Bloom readiness 门控是 8 月之后加的"),
    ("modules/ubiomodule/UBCCController.cc", "H64", "after", "2026-07-25",
     "H64 后备存储路径 0725 之后"),
]


def sha1_prefix(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root)

    print("== 1) 关键文件哈希对照（0717 基线） ==")
    matched = 0
    for rel, want in EXPECTED_HASHES.items():
        p = root / rel
        if not p.exists():
            print(f"  MISSING  {rel}")
            continue
        got = sha1_prefix(p)
        ok = "OK  " if got == want else "DIFF"
        matched += (got == want)
        print(f"  {ok}     {rel}  {got} (0717={want})")
    print(f"  => {matched}/{len(EXPECTED_HASHES)} 个文件与 0717 完全一致")

    print("\n== 2) 哨兵字符串推断 ==")
    ge_dates, le_dates, notes = [], [], []
    for rel, token, kind, date, why in SENTINELS:
        p = root / rel
        if not p.exists():
            continue
        text = ""
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        hit = p.exists() if not token else (token in text)
        if not hit:
            continue
        notes.append(f"  {rel}: 命中 '{token or '<文件存在>'}' => {date} ({why})")
        (ge_dates if kind == "after" else le_dates).append(date)
    print("\n".join(notes) if notes else "  (没有命中任何哨兵，可能是很早期或已大改的版本)")

    lo = max(ge_dates) if ge_dates else "?"
    hi = min(le_dates) if le_dates else "?"
    print(f"\n== 结论 ==")
    print(f"  推断窗口: {lo} .. {hi}")
    if matched == len(EXPECTED_HASHES):
        print("  关键文件哈希全中 => 极可能就是 0717 基线（gem5 63bc49e9ce）。")
    elif matched >= len(EXPECTED_HASHES) // 2:
        print("  多数文件与 0717 一致，但有私有改动；时间窗口参考上面的推断。")
    else:
        print("  与 0717 差异较大，请按推断窗口对照提交历史。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
